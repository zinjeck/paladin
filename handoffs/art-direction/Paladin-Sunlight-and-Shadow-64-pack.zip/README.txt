PALADIN - SUNLIGHT & SHADOW 64

This expands the existing 32-color palette to 64 while preserving every original color exactly.
The new half adds support for castles, temples, fortifications, armies, heraldry, roads, cold regions, and restrained fantasy accents.

Import into Krita: Palette docker menu -> Import Palette -> select Paladin-Sunlight-and-Shadow-64.gpl.
This remains an anchor palette, not a strict indexed-color limit. Blends and intermediate colors are still allowed when the art needs them.

Added groups:
- Stone & masonry: limestone, warm stone, granite, slate
- Metals: iron, steel, bronze, copper, verdigris
- Heraldry & ceremonial: crimson, red, purple, royal blue, azure, white
- Bone & leather: ivory and several leather values
- Earth & roads: dry earth, soil, mud, road dust
- Cold & fantasy: snow, ice, frost, arcane violet, aether cyan
